<html>

<body>

<a href="rtop.php">REQUEST</a>
<!--<form action="rtop.php" method="POST"> 
<input type="submit" value="Request" name="s">
</form>

<?php
if($_SERVER["REQUEST_METHOD"]=="POST"){
	
	include 'rtop.php';

}
?>
-->
</body>
</html>